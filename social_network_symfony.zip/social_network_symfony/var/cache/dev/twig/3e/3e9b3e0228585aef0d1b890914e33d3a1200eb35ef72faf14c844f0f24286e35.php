<?php

/* user/login.html.twig */
class __TwigTemplate_e174c2cb888a6f2ffe5ac4ae0f041615d1abf5130b3495ad18a2ca3e876116c0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout/layout.html.twig", "user/login.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9008baab9dbe3f0d4517c1216b8b13e20525bb19e4007a3d76b1397c9b674f29 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9008baab9dbe3f0d4517c1216b8b13e20525bb19e4007a3d76b1397c9b674f29->enter($__internal_9008baab9dbe3f0d4517c1216b8b13e20525bb19e4007a3d76b1397c9b674f29_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/login.html.twig"));

        $__internal_5df65c6ac5849ef4eb6455073e555fdc2848cd275520303c9e27f8d6e4acfb12 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5df65c6ac5849ef4eb6455073e555fdc2848cd275520303c9e27f8d6e4acfb12->enter($__internal_5df65c6ac5849ef4eb6455073e555fdc2848cd275520303c9e27f8d6e4acfb12_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9008baab9dbe3f0d4517c1216b8b13e20525bb19e4007a3d76b1397c9b674f29->leave($__internal_9008baab9dbe3f0d4517c1216b8b13e20525bb19e4007a3d76b1397c9b674f29_prof);

        
        $__internal_5df65c6ac5849ef4eb6455073e555fdc2848cd275520303c9e27f8d6e4acfb12->leave($__internal_5df65c6ac5849ef4eb6455073e555fdc2848cd275520303c9e27f8d6e4acfb12_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_1d273a7f888c77992c373450e0743d5c6f33e06b42a5b8d9e90b60a8b6848819 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1d273a7f888c77992c373450e0743d5c6f33e06b42a5b8d9e90b60a8b6848819->enter($__internal_1d273a7f888c77992c373450e0743d5c6f33e06b42a5b8d9e90b60a8b6848819_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_bfe6f1072881ddec3655001222e05d3ce62c3084e93da31b26c30251303cc8fd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bfe6f1072881ddec3655001222e05d3ce62c3084e93da31b26c30251303cc8fd->enter($__internal_bfe6f1072881ddec3655001222e05d3ce62c3084e93da31b26c30251303cc8fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-lg-4 col-lg-offset-4\">
                <div class=\"box-form\">
                    <h2>Log in</h2>
                    <form action=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login_check");
        echo "\" method=\"POST\">
                        <label>Email</label>
                        <input type=\"email\" id=\"username\" name=\"_username\" value=\"";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" class=\"form-control\" />
                        <label>Contraseña</label>
                        <input type=\"password\" id=\"passwords\" name=\"_password\" class=\"form-control\" />
                        <input type=\"submit\" value=\"Entrar\" class=\"btn btn-success\"/>
                        <input type=\"hidden\" name=\"_target_path\" value=\"/home\" />
                    </form>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_bfe6f1072881ddec3655001222e05d3ce62c3084e93da31b26c30251303cc8fd->leave($__internal_bfe6f1072881ddec3655001222e05d3ce62c3084e93da31b26c30251303cc8fd_prof);

        
        $__internal_1d273a7f888c77992c373450e0743d5c6f33e06b42a5b8d9e90b60a8b6848819->leave($__internal_1d273a7f888c77992c373450e0743d5c6f33e06b42a5b8d9e90b60a8b6848819_prof);

    }

    public function getTemplateName()
    {
        return "user/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 11,  56 => 9,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout/layout.html.twig' %}

{% block content %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-lg-4 col-lg-offset-4\">
                <div class=\"box-form\">
                    <h2>Log in</h2>
                    <form action=\"{{ path('login_check') }}\" method=\"POST\">
                        <label>Email</label>
                        <input type=\"email\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" class=\"form-control\" />
                        <label>Contraseña</label>
                        <input type=\"password\" id=\"passwords\" name=\"_password\" class=\"form-control\" />
                        <input type=\"submit\" value=\"Entrar\" class=\"btn btn-success\"/>
                        <input type=\"hidden\" name=\"_target_path\" value=\"/home\" />
                    </form>
                </div>
            </div>
        </div>
    </div>
{% endblock %}", "user/login.html.twig", "/Users/fabian/proyectos/cursos/symfony/red_social/app/Resources/views/user/login.html.twig");
    }
}

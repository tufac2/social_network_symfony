<?php

/* layout/layout.html.twig */
class __TwigTemplate_731f42ed7236b0724955d196f4ca9ed50a6811787e1b7ad920151b91387f62c3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1e19cdb4eb094be32da34370149b1f0277437a93c043beff9e73d35329a832f5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1e19cdb4eb094be32da34370149b1f0277437a93c043beff9e73d35329a832f5->enter($__internal_1e19cdb4eb094be32da34370149b1f0277437a93c043beff9e73d35329a832f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout/layout.html.twig"));

        $__internal_f10ab7e7dd00cc738f1cb0fbff5e902568fec0ce62d309111eb4a04f78a70478 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f10ab7e7dd00cc738f1cb0fbff5e902568fec0ce62d309111eb4a04f78a70478->enter($__internal_f10ab7e7dd00cc738f1cb0fbff5e902568fec0ce62d309111eb4a04f78a70478_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>
            ";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        // line 9
        echo "        </title>
        ";
        // line 10
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        <header>
            <nav class=\"navbar navbar-default\">
                <div class=\"container-fluid\">
                    <div class=\"navbar-header\">
                        <a class=\"navbar-brand\" href=\"";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_homepage");
        echo "\">
                            <span class=\"glyphicon glyphicon-cloud\"></span>
                            Social Network
                        </a>
                    </div>
                    <ul class=\"nav navbar-nav\">
                        <li class=\"active\">
                            <a href=\"";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_homepage");
        echo "\">
                                <span class=\"glyphicon glyphicon-home\"></span>
                                <span>Inicio</span>
                            </a>
                        </li>
                        <li>
                            <a href=\"";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_list");
        echo "\">Gente</a>
                        </li>
                    </ul>
                    <ul class=\"nav navbar-nav navbar-right\">
                        ";
        // line 40
        if (($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()) != null)) {
            // line 41
            echo "                            <li class=\"dropdown\">
                                <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">
                                    <div class=\"avatar\">
                                        ";
            // line 44
            if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "image", array()) == null)) {
                // line 45
                echo "                                        <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/default.png/"), "html", null, true);
                echo "\" />
                                        ";
            } else {
                // line 47
                echo "                                            <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(("uploads/users/" . $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "image", array()))), "html", null, true);
                echo "\" />
                                        ";
            }
            // line 49
            echo "                                    </div>
                                    ";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "name", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "surname", array()), "html", null, true);
            echo "
                                    <span class=\"caret\"></span>
                                </a>
                                <ul class=\"dropdown-menu\">
                                    <li>
                                        <a href=\"";
            // line 55
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_edit");
            echo "\">
                                            <span class=\"glyphicon glyphicon-cog\" aria-hidden=\"true\"></span>
                                            Mi Perfil
                                        </a>
                                    </li>
                                    <li role=\"separator\" class=\"divider\"></li>
                                    <li>
                                        <a>
                                            <span class=\"glyphicon glyphicon-question-sign\"></span>
                                            Ayuda
                                        </a>
                                    </li>
                                    <li>
                                        <a href=\"";
            // line 68
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("logout");
            echo "\">
                                            <span class=\"glyphicon glyphicon-log-out\"></span>
                                            Salir
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        ";
        } else {
            // line 76
            echo "                            <li>
                                <a href=\"";
            // line 77
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login");
            echo "\">
                                    <span class=\"glyphicon glyphicon-log-in\"></span>
                                    &nbsp;
                                    <span>Login</span>
                                </a>
                            </li>
                            <li>
                                <a href=\"";
            // line 84
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("register");
            echo "\">
                                    <span class=\"glyphicon glyphicon-user\"></span>
                                    &nbsp;
                                    <span>Registro</span>
                                </a>
                            </li>
                        ";
        }
        // line 91
        echo "                    </ul>
                </div>
            </nav>
        </header>
        <section id=\"content\">
            <div class=\"container\">
                <div class=\"col-lg-11\">
                    ";
        // line 98
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array(), "method"), "get", array(0 => "status"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 99
            echo "                        <div class=\"alert alert-success\">
                            ";
            // line 100
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 103
        echo "                </div>
            </div>
            <div class=\"clearfix\"></div>
            ";
        // line 106
        $this->displayBlock('content', $context, $blocks);
        // line 108
        echo "        </section>
        <footer>
            ";
        // line 110
        $this->displayBlock('footer', $context, $blocks);
        // line 115
        echo "        </footer>
        ";
        // line 116
        $this->displayBlock('javascripts', $context, $blocks);
        // line 123
        echo "    </body>

</html>
";
        
        $__internal_1e19cdb4eb094be32da34370149b1f0277437a93c043beff9e73d35329a832f5->leave($__internal_1e19cdb4eb094be32da34370149b1f0277437a93c043beff9e73d35329a832f5_prof);

        
        $__internal_f10ab7e7dd00cc738f1cb0fbff5e902568fec0ce62d309111eb4a04f78a70478->leave($__internal_f10ab7e7dd00cc738f1cb0fbff5e902568fec0ce62d309111eb4a04f78a70478_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_ed948829dc445f5020e6b01e8208e0a834f29b553d86a578b07f0389cfa94563 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ed948829dc445f5020e6b01e8208e0a834f29b553d86a578b07f0389cfa94563->enter($__internal_ed948829dc445f5020e6b01e8208e0a834f29b553d86a578b07f0389cfa94563_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_51e4737400ae53ac02d4532317d240c1892b20ad349054e09c0796421c60ccbf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_51e4737400ae53ac02d4532317d240c1892b20ad349054e09c0796421c60ccbf->enter($__internal_51e4737400ae53ac02d4532317d240c1892b20ad349054e09c0796421c60ccbf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 7
        echo "            - Deporte para Todos
            ";
        
        $__internal_51e4737400ae53ac02d4532317d240c1892b20ad349054e09c0796421c60ccbf->leave($__internal_51e4737400ae53ac02d4532317d240c1892b20ad349054e09c0796421c60ccbf_prof);

        
        $__internal_ed948829dc445f5020e6b01e8208e0a834f29b553d86a578b07f0389cfa94563->leave($__internal_ed948829dc445f5020e6b01e8208e0a834f29b553d86a578b07f0389cfa94563_prof);

    }

    // line 10
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ea62ac90928957b3f44fd5140a63ada1db2950cab6a00e42864dbe970adb6a92 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ea62ac90928957b3f44fd5140a63ada1db2950cab6a00e42864dbe970adb6a92->enter($__internal_ea62ac90928957b3f44fd5140a63ada1db2950cab6a00e42864dbe970adb6a92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_c945941d27f1fbcfc449fe0aa9113977e3fa7d472a373a9a5bb07106a1f7bb19 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c945941d27f1fbcfc449fe0aa9113977e3fa7d472a373a9a5bb07106a1f7bb19->enter($__internal_c945941d27f1fbcfc449fe0aa9113977e3fa7d472a373a9a5bb07106a1f7bb19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 11
        echo "            ";
        // line 12
        echo "            <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/bootstrap/css/bootstrap.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\"/>
            <link href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/bootstrap.cosmo.min.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\"/>
            <link href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/styles.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\"/>
        ";
        
        $__internal_c945941d27f1fbcfc449fe0aa9113977e3fa7d472a373a9a5bb07106a1f7bb19->leave($__internal_c945941d27f1fbcfc449fe0aa9113977e3fa7d472a373a9a5bb07106a1f7bb19_prof);

        
        $__internal_ea62ac90928957b3f44fd5140a63ada1db2950cab6a00e42864dbe970adb6a92->leave($__internal_ea62ac90928957b3f44fd5140a63ada1db2950cab6a00e42864dbe970adb6a92_prof);

    }

    // line 106
    public function block_content($context, array $blocks = array())
    {
        $__internal_7e38ce4768c2cebda498d5b175b699b11137e018d7086162d167c4e1594f17a5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7e38ce4768c2cebda498d5b175b699b11137e018d7086162d167c4e1594f17a5->enter($__internal_7e38ce4768c2cebda498d5b175b699b11137e018d7086162d167c4e1594f17a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_a7531a0d25c7a0eea1f6ed94060753b59573ba92cc0955ca2b653bc9af3c1928 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a7531a0d25c7a0eea1f6ed94060753b59573ba92cc0955ca2b653bc9af3c1928->enter($__internal_a7531a0d25c7a0eea1f6ed94060753b59573ba92cc0955ca2b653bc9af3c1928_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 107
        echo "            ";
        
        $__internal_a7531a0d25c7a0eea1f6ed94060753b59573ba92cc0955ca2b653bc9af3c1928->leave($__internal_a7531a0d25c7a0eea1f6ed94060753b59573ba92cc0955ca2b653bc9af3c1928_prof);

        
        $__internal_7e38ce4768c2cebda498d5b175b699b11137e018d7086162d167c4e1594f17a5->leave($__internal_7e38ce4768c2cebda498d5b175b699b11137e018d7086162d167c4e1594f17a5_prof);

    }

    // line 110
    public function block_footer($context, array $blocks = array())
    {
        $__internal_5ebc6be8729b410dc1633790e97bf58da7d211a01e7f75fcef9da187212b659b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5ebc6be8729b410dc1633790e97bf58da7d211a01e7f75fcef9da187212b659b->enter($__internal_5ebc6be8729b410dc1633790e97bf58da7d211a01e7f75fcef9da187212b659b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_d97a3c2751ce805f887a45fcafeeabecc14480256b32fa8b663ea466c4751b46 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d97a3c2751ce805f887a45fcafeeabecc14480256b32fa8b663ea466c4751b46->enter($__internal_d97a3c2751ce805f887a45fcafeeabecc14480256b32fa8b663ea466c4751b46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 111
        echo "                <div class=\"container\">
                    <p class=\"text-muted\">Social Network</p>
                </div>
            ";
        
        $__internal_d97a3c2751ce805f887a45fcafeeabecc14480256b32fa8b663ea466c4751b46->leave($__internal_d97a3c2751ce805f887a45fcafeeabecc14480256b32fa8b663ea466c4751b46_prof);

        
        $__internal_5ebc6be8729b410dc1633790e97bf58da7d211a01e7f75fcef9da187212b659b->leave($__internal_5ebc6be8729b410dc1633790e97bf58da7d211a01e7f75fcef9da187212b659b_prof);

    }

    // line 116
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_4683aa433fdec7a49bb09e00c1bf0244293e4d9495d232abf5d0b6b455159f88 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4683aa433fdec7a49bb09e00c1bf0244293e4d9495d232abf5d0b6b455159f88->enter($__internal_4683aa433fdec7a49bb09e00c1bf0244293e4d9495d232abf5d0b6b455159f88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_42ff3fd5af522f566fe42df461e0eda7a9c00ef86ab31c1de9d2247e2c78ed94 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_42ff3fd5af522f566fe42df461e0eda7a9c00ef86ab31c1de9d2247e2c78ed94->enter($__internal_42ff3fd5af522f566fe42df461e0eda7a9c00ef86ab31c1de9d2247e2c78ed94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 117
        echo "            <script type=\"text/javascript\">
                var URL = \"";
        // line 118
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "getSchemeAndHttpHost", array(), "method"), "html", null, true);
        echo "\";
            </script>
            <script src=\"";
        // line 120
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/jquery.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 121
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/bootstrap/js/bootstrap.js"), "html", null, true);
        echo "\"></script>
        ";
        
        $__internal_42ff3fd5af522f566fe42df461e0eda7a9c00ef86ab31c1de9d2247e2c78ed94->leave($__internal_42ff3fd5af522f566fe42df461e0eda7a9c00ef86ab31c1de9d2247e2c78ed94_prof);

        
        $__internal_4683aa433fdec7a49bb09e00c1bf0244293e4d9495d232abf5d0b6b455159f88->leave($__internal_4683aa433fdec7a49bb09e00c1bf0244293e4d9495d232abf5d0b6b455159f88_prof);

    }

    public function getTemplateName()
    {
        return "layout/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  335 => 121,  331 => 120,  326 => 118,  323 => 117,  314 => 116,  301 => 111,  292 => 110,  282 => 107,  273 => 106,  261 => 14,  257 => 13,  252 => 12,  250 => 11,  241 => 10,  230 => 7,  221 => 6,  208 => 123,  206 => 116,  203 => 115,  201 => 110,  197 => 108,  195 => 106,  190 => 103,  181 => 100,  178 => 99,  174 => 98,  165 => 91,  155 => 84,  145 => 77,  142 => 76,  131 => 68,  115 => 55,  105 => 50,  102 => 49,  96 => 47,  90 => 45,  88 => 44,  83 => 41,  81 => 40,  74 => 36,  65 => 30,  55 => 23,  44 => 16,  42 => 10,  39 => 9,  37 => 6,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>
            {% block title %}
            - Deporte para Todos
            {% endblock %}
        </title>
        {% block stylesheets %}
            {# Incluir estilos CSS #}
            <link href=\"{{ asset('assets/bootstrap/css/bootstrap.css') }}\" type=\"text/css\" rel=\"stylesheet\"/>
            <link href=\"{{ asset('assets/css/bootstrap.cosmo.min.css') }}\" type=\"text/css\" rel=\"stylesheet\"/>
            <link href=\"{{ asset('assets/css/styles.css') }}\" type=\"text/css\" rel=\"stylesheet\"/>
        {% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        <header>
            <nav class=\"navbar navbar-default\">
                <div class=\"container-fluid\">
                    <div class=\"navbar-header\">
                        <a class=\"navbar-brand\" href=\"{{ path(\"app_homepage\") }}\">
                            <span class=\"glyphicon glyphicon-cloud\"></span>
                            Social Network
                        </a>
                    </div>
                    <ul class=\"nav navbar-nav\">
                        <li class=\"active\">
                            <a href=\"{{ path(\"app_homepage\") }}\">
                                <span class=\"glyphicon glyphicon-home\"></span>
                                <span>Inicio</span>
                            </a>
                        </li>
                        <li>
                            <a href=\"{{ path(\"user_list\") }}\">Gente</a>
                        </li>
                    </ul>
                    <ul class=\"nav navbar-nav navbar-right\">
                        {% if app.user != null %}
                            <li class=\"dropdown\">
                                <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">
                                    <div class=\"avatar\">
                                        {% if app.user.image == null %}
                                        <img src=\"{{ asset('images/default.png/') }}\" />
                                        {% else %}
                                            <img src=\"{{ asset('uploads/users/'~app.user.image) }}\" />
                                        {% endif %}
                                    </div>
                                    {{ app.user.name }} {{ app.user.surname }}
                                    <span class=\"caret\"></span>
                                </a>
                                <ul class=\"dropdown-menu\">
                                    <li>
                                        <a href=\"{{ path(\"user_edit\") }}\">
                                            <span class=\"glyphicon glyphicon-cog\" aria-hidden=\"true\"></span>
                                            Mi Perfil
                                        </a>
                                    </li>
                                    <li role=\"separator\" class=\"divider\"></li>
                                    <li>
                                        <a>
                                            <span class=\"glyphicon glyphicon-question-sign\"></span>
                                            Ayuda
                                        </a>
                                    </li>
                                    <li>
                                        <a href=\"{{ path(\"logout\") }}\">
                                            <span class=\"glyphicon glyphicon-log-out\"></span>
                                            Salir
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        {% else %}
                            <li>
                                <a href=\"{{ path(\"login\") }}\">
                                    <span class=\"glyphicon glyphicon-log-in\"></span>
                                    &nbsp;
                                    <span>Login</span>
                                </a>
                            </li>
                            <li>
                                <a href=\"{{ path(\"register\") }}\">
                                    <span class=\"glyphicon glyphicon-user\"></span>
                                    &nbsp;
                                    <span>Registro</span>
                                </a>
                            </li>
                        {% endif %}
                    </ul>
                </div>
            </nav>
        </header>
        <section id=\"content\">
            <div class=\"container\">
                <div class=\"col-lg-11\">
                    {% for message in app.session.flashbag().get('status') %}
                        <div class=\"alert alert-success\">
                            {{ message }}
                        </div>
                    {% endfor %}
                </div>
            </div>
            <div class=\"clearfix\"></div>
            {% block content %}
            {% endblock %}
        </section>
        <footer>
            {% block footer %}
                <div class=\"container\">
                    <p class=\"text-muted\">Social Network</p>
                </div>
            {% endblock %}
        </footer>
        {% block javascripts %}
            <script type=\"text/javascript\">
                var URL = \"{{ app.request.getSchemeAndHttpHost() }}\";
            </script>
            <script src=\"{{ asset('assets/js/jquery.min.js') }}\"></script>
            <script src=\"{{ asset('assets/bootstrap/js/bootstrap.js') }}\"></script>
        {% endblock %}
    </body>

</html>
", "layout/layout.html.twig", "/Users/fabian/proyectos/cursos/symfony/red_social/app/Resources/views/layout/layout.html.twig");
    }
}

<?php

/* user/login.html.twig */
class __TwigTemplate_bd9be4ddc479054d945d8857195e60e4c2273a9b3683bd160ee44322d348c582 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout/layout.html.twig", "user/login.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a6b1e09973cb682f0b3b00869f1f91ce8f2e3cf5aa9916eb0d42772af9129671 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a6b1e09973cb682f0b3b00869f1f91ce8f2e3cf5aa9916eb0d42772af9129671->enter($__internal_a6b1e09973cb682f0b3b00869f1f91ce8f2e3cf5aa9916eb0d42772af9129671_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/login.html.twig"));

        $__internal_f93eff60e7a7ce6ab4555bce79b1e73c583fdc82ef8547838e85776cf901e42c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f93eff60e7a7ce6ab4555bce79b1e73c583fdc82ef8547838e85776cf901e42c->enter($__internal_f93eff60e7a7ce6ab4555bce79b1e73c583fdc82ef8547838e85776cf901e42c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a6b1e09973cb682f0b3b00869f1f91ce8f2e3cf5aa9916eb0d42772af9129671->leave($__internal_a6b1e09973cb682f0b3b00869f1f91ce8f2e3cf5aa9916eb0d42772af9129671_prof);

        
        $__internal_f93eff60e7a7ce6ab4555bce79b1e73c583fdc82ef8547838e85776cf901e42c->leave($__internal_f93eff60e7a7ce6ab4555bce79b1e73c583fdc82ef8547838e85776cf901e42c_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_5ab4098a5b5a7126e3a34f3eb6c883dabeef2536e1a4e6699bb9ca0b7fe71a0d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5ab4098a5b5a7126e3a34f3eb6c883dabeef2536e1a4e6699bb9ca0b7fe71a0d->enter($__internal_5ab4098a5b5a7126e3a34f3eb6c883dabeef2536e1a4e6699bb9ca0b7fe71a0d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_ca5b5885f307635955e395d615e377105e5390dfa510bed0b7cd4f8bfecf48b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca5b5885f307635955e395d615e377105e5390dfa510bed0b7cd4f8bfecf48b9->enter($__internal_ca5b5885f307635955e395d615e377105e5390dfa510bed0b7cd4f8bfecf48b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-lg-4 col-lg-offset-4\">
                <div class=\"box-form\">
                    <h2>Log in</h2>
                    <form action=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login_check");
        echo "\" method=\"POST\">
                        <label>Email</label>
                        <input type=\"email\" id=\"username\" name=\"_username\" value=\"";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" class=\"form-control\" />
                        <label>Contraseña</label>
                        <input type=\"password\" id=\"passwords\" name=\"_password\" class=\"form-control\" />
                        <input type=\"submit\" value=\"Entrar\" class=\"btn btn-success\"/>
                        <input type=\"hidden\" name=\"_target_path\" value=\"/home\" />
                    </form>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_ca5b5885f307635955e395d615e377105e5390dfa510bed0b7cd4f8bfecf48b9->leave($__internal_ca5b5885f307635955e395d615e377105e5390dfa510bed0b7cd4f8bfecf48b9_prof);

        
        $__internal_5ab4098a5b5a7126e3a34f3eb6c883dabeef2536e1a4e6699bb9ca0b7fe71a0d->leave($__internal_5ab4098a5b5a7126e3a34f3eb6c883dabeef2536e1a4e6699bb9ca0b7fe71a0d_prof);

    }

    public function getTemplateName()
    {
        return "user/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 11,  56 => 9,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout/layout.html.twig' %}

{% block content %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-lg-4 col-lg-offset-4\">
                <div class=\"box-form\">
                    <h2>Log in</h2>
                    <form action=\"{{ path('login_check') }}\" method=\"POST\">
                        <label>Email</label>
                        <input type=\"email\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" class=\"form-control\" />
                        <label>Contraseña</label>
                        <input type=\"password\" id=\"passwords\" name=\"_password\" class=\"form-control\" />
                        <input type=\"submit\" value=\"Entrar\" class=\"btn btn-success\"/>
                        <input type=\"hidden\" name=\"_target_path\" value=\"/home\" />
                    </form>
                </div>
            </div>
        </div>
    </div>
{% endblock %}", "user/login.html.twig", "/Users/fabian/proyectos/cursos/symfony/red_social/app/Resources/views/user/login.html.twig");
    }
}

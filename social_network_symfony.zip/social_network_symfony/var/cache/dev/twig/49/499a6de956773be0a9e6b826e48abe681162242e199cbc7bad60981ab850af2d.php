<?php

/* layout/layout.html.twig */
class __TwigTemplate_75910e390303e12969faf072fbfd1e413073d10b01341f1093e9272f583a5aa2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ef4a16ea1b9765f6b424db2a58c3bdfd46eb0b100318a8ac665e0a4e56c6a258 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ef4a16ea1b9765f6b424db2a58c3bdfd46eb0b100318a8ac665e0a4e56c6a258->enter($__internal_ef4a16ea1b9765f6b424db2a58c3bdfd46eb0b100318a8ac665e0a4e56c6a258_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout/layout.html.twig"));

        $__internal_c2cd6ec41f2de50da406685dbeb207f07d9df9c7fc77ca608096a5e25260d9b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c2cd6ec41f2de50da406685dbeb207f07d9df9c7fc77ca608096a5e25260d9b6->enter($__internal_c2cd6ec41f2de50da406685dbeb207f07d9df9c7fc77ca608096a5e25260d9b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>
            ";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        // line 9
        echo "        </title>
        ";
        // line 10
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        <header>
            <nav class=\"navbar navbar-default\">
                <div class=\"container-fluid\">
                    <div class=\"navbar-header\">
                        <a class=\"navbar-brand\" href=\"";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_homepage");
        echo "\">
                            <span class=\"glyphicon glyphicon-cloud\"></span>
                            Social Network
                        </a>
                    </div>
                    <ul class=\"nav navbar-nav\">
                        <li class=\"active\">
                            <a href=\"";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_homepage");
        echo "\">
                                <span class=\"glyphicon glyphicon-home\"></span>
                                <span>Inicio</span>
                            </a>
                        </li>
                        <li>
                            <a href=\"";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_list");
        echo "\">Gente</a>
                        </li>
                    </ul>
                    <ul class=\"nav navbar-nav navbar-right\">
                        ";
        // line 40
        if (($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()) != null)) {
            // line 41
            echo "                            <li class=\"dropdown\">
                                <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">
                                    <div class=\"avatar\">
                                        ";
            // line 44
            if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "image", array()) == null)) {
                // line 45
                echo "                                        <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/default.png/"), "html", null, true);
                echo "\" />
                                        ";
            } else {
                // line 47
                echo "                                            <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(("uploads/users/" . $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "image", array()))), "html", null, true);
                echo "\" />
                                        ";
            }
            // line 49
            echo "                                    </div>
                                    ";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "name", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "surname", array()), "html", null, true);
            echo "
                                    <span class=\"caret\"></span>
                                </a>
                                <ul class=\"dropdown-menu\">
                                    <li>
                                        <a href=\"";
            // line 55
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_edit");
            echo "\">
                                            <span class=\"glyphicon glyphicon-cog\" aria-hidden=\"true\"></span>
                                            Mi Perfil
                                        </a>
                                    </li>
                                    <li role=\"separator\" class=\"divider\"></li>
                                    <li>
                                        <a>
                                            <span class=\"glyphicon glyphicon-question-sign\"></span>
                                            Ayuda
                                        </a>
                                    </li>
                                    <li>
                                        <a href=\"";
            // line 68
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("logout");
            echo "\">
                                            <span class=\"glyphicon glyphicon-log-out\"></span>
                                            Salir
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        ";
        } else {
            // line 76
            echo "                            <li>
                                <a href=\"";
            // line 77
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login");
            echo "\">
                                    <span class=\"glyphicon glyphicon-log-in\"></span>
                                    &nbsp;
                                    <span>Login</span>
                                </a>
                            </li>
                            <li>
                                <a href=\"";
            // line 84
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("register");
            echo "\">
                                    <span class=\"glyphicon glyphicon-user\"></span>
                                    &nbsp;
                                    <span>Registro</span>
                                </a>
                            </li>
                        ";
        }
        // line 91
        echo "                    </ul>
                </div>
            </nav>
        </header>
        <section id=\"content\">
            <div class=\"container\">
                <div class=\"col-lg-11\">
                    ";
        // line 98
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array(), "method"), "get", array(0 => "status"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 99
            echo "                        <div class=\"alert alert-success\">
                            ";
            // line 100
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 103
        echo "                </div>
            </div>
            <div class=\"clearfix\"></div>
            ";
        // line 106
        $this->displayBlock('content', $context, $blocks);
        // line 108
        echo "        </section>
        <footer>
            ";
        // line 110
        $this->displayBlock('footer', $context, $blocks);
        // line 115
        echo "        </footer>
        ";
        // line 116
        $this->displayBlock('javascripts', $context, $blocks);
        // line 123
        echo "    </body>

</html>
";
        
        $__internal_ef4a16ea1b9765f6b424db2a58c3bdfd46eb0b100318a8ac665e0a4e56c6a258->leave($__internal_ef4a16ea1b9765f6b424db2a58c3bdfd46eb0b100318a8ac665e0a4e56c6a258_prof);

        
        $__internal_c2cd6ec41f2de50da406685dbeb207f07d9df9c7fc77ca608096a5e25260d9b6->leave($__internal_c2cd6ec41f2de50da406685dbeb207f07d9df9c7fc77ca608096a5e25260d9b6_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_7ccb07dc293eab22b5060e731c23a4914c8cd49206b8e59c306958eb68821b32 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7ccb07dc293eab22b5060e731c23a4914c8cd49206b8e59c306958eb68821b32->enter($__internal_7ccb07dc293eab22b5060e731c23a4914c8cd49206b8e59c306958eb68821b32_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_56ee552c80bacaa8c89a41b3792e7e514de235051cb8990f9c2025d4d887419d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_56ee552c80bacaa8c89a41b3792e7e514de235051cb8990f9c2025d4d887419d->enter($__internal_56ee552c80bacaa8c89a41b3792e7e514de235051cb8990f9c2025d4d887419d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 7
        echo "            - Deporte para Todos
            ";
        
        $__internal_56ee552c80bacaa8c89a41b3792e7e514de235051cb8990f9c2025d4d887419d->leave($__internal_56ee552c80bacaa8c89a41b3792e7e514de235051cb8990f9c2025d4d887419d_prof);

        
        $__internal_7ccb07dc293eab22b5060e731c23a4914c8cd49206b8e59c306958eb68821b32->leave($__internal_7ccb07dc293eab22b5060e731c23a4914c8cd49206b8e59c306958eb68821b32_prof);

    }

    // line 10
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_8714639f873c8f5f961f184b54626d3300428697419a1ce6a947791433950021 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8714639f873c8f5f961f184b54626d3300428697419a1ce6a947791433950021->enter($__internal_8714639f873c8f5f961f184b54626d3300428697419a1ce6a947791433950021_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_f098c33f009e52694470b6dba229f7226a4cdf63d51fcf403f9f71be02429e04 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f098c33f009e52694470b6dba229f7226a4cdf63d51fcf403f9f71be02429e04->enter($__internal_f098c33f009e52694470b6dba229f7226a4cdf63d51fcf403f9f71be02429e04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 11
        echo "            ";
        // line 12
        echo "            <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/bootstrap/css/bootstrap.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\"/>
            <link href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/bootstrap.cosmo.min.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\"/>
            <link href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/styles.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\"/>
        ";
        
        $__internal_f098c33f009e52694470b6dba229f7226a4cdf63d51fcf403f9f71be02429e04->leave($__internal_f098c33f009e52694470b6dba229f7226a4cdf63d51fcf403f9f71be02429e04_prof);

        
        $__internal_8714639f873c8f5f961f184b54626d3300428697419a1ce6a947791433950021->leave($__internal_8714639f873c8f5f961f184b54626d3300428697419a1ce6a947791433950021_prof);

    }

    // line 106
    public function block_content($context, array $blocks = array())
    {
        $__internal_4feedd9aaabaabc6eabcc7f417aa299689ee948816117d12b0b2894de1069d47 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4feedd9aaabaabc6eabcc7f417aa299689ee948816117d12b0b2894de1069d47->enter($__internal_4feedd9aaabaabc6eabcc7f417aa299689ee948816117d12b0b2894de1069d47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_3132e6f41e67bcf9fe6335efece340ccb503887349bdb8af5358b03939f2b972 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3132e6f41e67bcf9fe6335efece340ccb503887349bdb8af5358b03939f2b972->enter($__internal_3132e6f41e67bcf9fe6335efece340ccb503887349bdb8af5358b03939f2b972_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 107
        echo "            ";
        
        $__internal_3132e6f41e67bcf9fe6335efece340ccb503887349bdb8af5358b03939f2b972->leave($__internal_3132e6f41e67bcf9fe6335efece340ccb503887349bdb8af5358b03939f2b972_prof);

        
        $__internal_4feedd9aaabaabc6eabcc7f417aa299689ee948816117d12b0b2894de1069d47->leave($__internal_4feedd9aaabaabc6eabcc7f417aa299689ee948816117d12b0b2894de1069d47_prof);

    }

    // line 110
    public function block_footer($context, array $blocks = array())
    {
        $__internal_6c1546105ffaa7a3d10b8f10979a84b6e33352a87de68fc06f4bd8e2bf6cd847 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6c1546105ffaa7a3d10b8f10979a84b6e33352a87de68fc06f4bd8e2bf6cd847->enter($__internal_6c1546105ffaa7a3d10b8f10979a84b6e33352a87de68fc06f4bd8e2bf6cd847_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_466829201a8ad63c05b3bb289fca26be8b0e96990c8fd92f3d6625d8cb301ab7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_466829201a8ad63c05b3bb289fca26be8b0e96990c8fd92f3d6625d8cb301ab7->enter($__internal_466829201a8ad63c05b3bb289fca26be8b0e96990c8fd92f3d6625d8cb301ab7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 111
        echo "                <div class=\"container\">
                    <p class=\"text-muted\">Social Network</p>
                </div>
            ";
        
        $__internal_466829201a8ad63c05b3bb289fca26be8b0e96990c8fd92f3d6625d8cb301ab7->leave($__internal_466829201a8ad63c05b3bb289fca26be8b0e96990c8fd92f3d6625d8cb301ab7_prof);

        
        $__internal_6c1546105ffaa7a3d10b8f10979a84b6e33352a87de68fc06f4bd8e2bf6cd847->leave($__internal_6c1546105ffaa7a3d10b8f10979a84b6e33352a87de68fc06f4bd8e2bf6cd847_prof);

    }

    // line 116
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_6c82613aa4ff8424552069983acc47edc3a6df7016b43f7307728f9dc10c7914 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6c82613aa4ff8424552069983acc47edc3a6df7016b43f7307728f9dc10c7914->enter($__internal_6c82613aa4ff8424552069983acc47edc3a6df7016b43f7307728f9dc10c7914_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_f9d0b53e73f5205fec1f8cad00b7dfed81e5e2ba7597cdeae9bd8538032113e4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f9d0b53e73f5205fec1f8cad00b7dfed81e5e2ba7597cdeae9bd8538032113e4->enter($__internal_f9d0b53e73f5205fec1f8cad00b7dfed81e5e2ba7597cdeae9bd8538032113e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 117
        echo "            <script type=\"text/javascript\">
                var URL = \"";
        // line 118
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "getSchemeAndHttpHost", array(), "method"), "html", null, true);
        echo "\";
            </script>
            <script src=\"";
        // line 120
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/jquery.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 121
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/bootstrap/js/bootstrap.js"), "html", null, true);
        echo "\"></script>
        ";
        
        $__internal_f9d0b53e73f5205fec1f8cad00b7dfed81e5e2ba7597cdeae9bd8538032113e4->leave($__internal_f9d0b53e73f5205fec1f8cad00b7dfed81e5e2ba7597cdeae9bd8538032113e4_prof);

        
        $__internal_6c82613aa4ff8424552069983acc47edc3a6df7016b43f7307728f9dc10c7914->leave($__internal_6c82613aa4ff8424552069983acc47edc3a6df7016b43f7307728f9dc10c7914_prof);

    }

    public function getTemplateName()
    {
        return "layout/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  335 => 121,  331 => 120,  326 => 118,  323 => 117,  314 => 116,  301 => 111,  292 => 110,  282 => 107,  273 => 106,  261 => 14,  257 => 13,  252 => 12,  250 => 11,  241 => 10,  230 => 7,  221 => 6,  208 => 123,  206 => 116,  203 => 115,  201 => 110,  197 => 108,  195 => 106,  190 => 103,  181 => 100,  178 => 99,  174 => 98,  165 => 91,  155 => 84,  145 => 77,  142 => 76,  131 => 68,  115 => 55,  105 => 50,  102 => 49,  96 => 47,  90 => 45,  88 => 44,  83 => 41,  81 => 40,  74 => 36,  65 => 30,  55 => 23,  44 => 16,  42 => 10,  39 => 9,  37 => 6,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>
            {% block title %}
            - Deporte para Todos
            {% endblock %}
        </title>
        {% block stylesheets %}
            {# Incluir estilos CSS #}
            <link href=\"{{ asset('assets/bootstrap/css/bootstrap.css') }}\" type=\"text/css\" rel=\"stylesheet\"/>
            <link href=\"{{ asset('assets/css/bootstrap.cosmo.min.css') }}\" type=\"text/css\" rel=\"stylesheet\"/>
            <link href=\"{{ asset('assets/css/styles.css') }}\" type=\"text/css\" rel=\"stylesheet\"/>
        {% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        <header>
            <nav class=\"navbar navbar-default\">
                <div class=\"container-fluid\">
                    <div class=\"navbar-header\">
                        <a class=\"navbar-brand\" href=\"{{ path(\"app_homepage\") }}\">
                            <span class=\"glyphicon glyphicon-cloud\"></span>
                            Social Network
                        </a>
                    </div>
                    <ul class=\"nav navbar-nav\">
                        <li class=\"active\">
                            <a href=\"{{ path(\"app_homepage\") }}\">
                                <span class=\"glyphicon glyphicon-home\"></span>
                                <span>Inicio</span>
                            </a>
                        </li>
                        <li>
                            <a href=\"{{ path(\"user_list\") }}\">Gente</a>
                        </li>
                    </ul>
                    <ul class=\"nav navbar-nav navbar-right\">
                        {% if app.user != null %}
                            <li class=\"dropdown\">
                                <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">
                                    <div class=\"avatar\">
                                        {% if app.user.image == null %}
                                        <img src=\"{{ asset('images/default.png/') }}\" />
                                        {% else %}
                                            <img src=\"{{ asset('uploads/users/'~app.user.image) }}\" />
                                        {% endif %}
                                    </div>
                                    {{ app.user.name }} {{ app.user.surname }}
                                    <span class=\"caret\"></span>
                                </a>
                                <ul class=\"dropdown-menu\">
                                    <li>
                                        <a href=\"{{ path(\"user_edit\") }}\">
                                            <span class=\"glyphicon glyphicon-cog\" aria-hidden=\"true\"></span>
                                            Mi Perfil
                                        </a>
                                    </li>
                                    <li role=\"separator\" class=\"divider\"></li>
                                    <li>
                                        <a>
                                            <span class=\"glyphicon glyphicon-question-sign\"></span>
                                            Ayuda
                                        </a>
                                    </li>
                                    <li>
                                        <a href=\"{{ path(\"logout\") }}\">
                                            <span class=\"glyphicon glyphicon-log-out\"></span>
                                            Salir
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        {% else %}
                            <li>
                                <a href=\"{{ path(\"login\") }}\">
                                    <span class=\"glyphicon glyphicon-log-in\"></span>
                                    &nbsp;
                                    <span>Login</span>
                                </a>
                            </li>
                            <li>
                                <a href=\"{{ path(\"register\") }}\">
                                    <span class=\"glyphicon glyphicon-user\"></span>
                                    &nbsp;
                                    <span>Registro</span>
                                </a>
                            </li>
                        {% endif %}
                    </ul>
                </div>
            </nav>
        </header>
        <section id=\"content\">
            <div class=\"container\">
                <div class=\"col-lg-11\">
                    {% for message in app.session.flashbag().get('status') %}
                        <div class=\"alert alert-success\">
                            {{ message }}
                        </div>
                    {% endfor %}
                </div>
            </div>
            <div class=\"clearfix\"></div>
            {% block content %}
            {% endblock %}
        </section>
        <footer>
            {% block footer %}
                <div class=\"container\">
                    <p class=\"text-muted\">Social Network</p>
                </div>
            {% endblock %}
        </footer>
        {% block javascripts %}
            <script type=\"text/javascript\">
                var URL = \"{{ app.request.getSchemeAndHttpHost() }}\";
            </script>
            <script src=\"{{ asset('assets/js/jquery.min.js') }}\"></script>
            <script src=\"{{ asset('assets/bootstrap/js/bootstrap.js') }}\"></script>
        {% endblock %}
    </body>

</html>
", "layout/layout.html.twig", "/Users/fabian/proyectos/cursos/symfony/red_social/app/Resources/views/layout/layout.html.twig");
    }
}

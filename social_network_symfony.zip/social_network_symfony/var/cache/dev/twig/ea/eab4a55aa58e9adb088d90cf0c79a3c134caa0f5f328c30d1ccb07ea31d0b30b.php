<?php

/* publication/home.html.twig */
class __TwigTemplate_cbc7bf33ef12b24151ffa0704b0c3b23cc34a54d53dbca9fd9d8ec0b66af2704 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout/layout.html.twig", "publication/home.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4b75cce8d88af27e6312ddd77cfbbe54ccf7d24b69097d587247513db2a1721e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4b75cce8d88af27e6312ddd77cfbbe54ccf7d24b69097d587247513db2a1721e->enter($__internal_4b75cce8d88af27e6312ddd77cfbbe54ccf7d24b69097d587247513db2a1721e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "publication/home.html.twig"));

        $__internal_3559a625a6bec9acaa76874271812d2ecddb1c530cdb04a47e54a0b078b9be42 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3559a625a6bec9acaa76874271812d2ecddb1c530cdb04a47e54a0b078b9be42->enter($__internal_3559a625a6bec9acaa76874271812d2ecddb1c530cdb04a47e54a0b078b9be42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "publication/home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4b75cce8d88af27e6312ddd77cfbbe54ccf7d24b69097d587247513db2a1721e->leave($__internal_4b75cce8d88af27e6312ddd77cfbbe54ccf7d24b69097d587247513db2a1721e_prof);

        
        $__internal_3559a625a6bec9acaa76874271812d2ecddb1c530cdb04a47e54a0b078b9be42->leave($__internal_3559a625a6bec9acaa76874271812d2ecddb1c530cdb04a47e54a0b078b9be42_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_74145a4a051728c2193dcfbba01daaecc44abcf6e8a7a51d400b7ea2927b172f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_74145a4a051728c2193dcfbba01daaecc44abcf6e8a7a51d400b7ea2927b172f->enter($__internal_74145a4a051728c2193dcfbba01daaecc44abcf6e8a7a51d400b7ea2927b172f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_3b06e117ab20a5bc2469aa117b574718546ff1fcb43384f7d58ffc6050ca8673 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3b06e117ab20a5bc2469aa117b574718546ff1fcb43384f7d58ffc6050ca8673->enter($__internal_3b06e117ab20a5bc2469aa117b574718546ff1fcb43384f7d58ffc6050ca8673_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "    <h1>Hola</h1>
";
        
        $__internal_3b06e117ab20a5bc2469aa117b574718546ff1fcb43384f7d58ffc6050ca8673->leave($__internal_3b06e117ab20a5bc2469aa117b574718546ff1fcb43384f7d58ffc6050ca8673_prof);

        
        $__internal_74145a4a051728c2193dcfbba01daaecc44abcf6e8a7a51d400b7ea2927b172f->leave($__internal_74145a4a051728c2193dcfbba01daaecc44abcf6e8a7a51d400b7ea2927b172f_prof);

    }

    public function getTemplateName()
    {
        return "publication/home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout/layout.html.twig' %}
{% block content %}
    <h1>Hola</h1>
{% endblock %}", "publication/home.html.twig", "/Users/fabian/proyectos/cursos/symfony/red_social/app/Resources/views/publication/home.html.twig");
    }
}

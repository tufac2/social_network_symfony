<?php

/* @Twig/images/chevron-right.svg */
class __TwigTemplate_d34ae21e69729bd3713fe08d11af124b2d73dbee7065b8255f4f8dc5affcfea6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a120e020da9eb9b8ef4e3498818ee4b7d87af81bc2d9e0d17129470ef5fe6ec1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a120e020da9eb9b8ef4e3498818ee4b7d87af81bc2d9e0d17129470ef5fe6ec1->enter($__internal_a120e020da9eb9b8ef4e3498818ee4b7d87af81bc2d9e0d17129470ef5fe6ec1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        $__internal_5550285b1606262e783eb9a0ba8be4e8f048308dfbb07f522cc60519f4fee585 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5550285b1606262e783eb9a0ba8be4e8f048308dfbb07f522cc60519f4fee585->enter($__internal_5550285b1606262e783eb9a0ba8be4e8f048308dfbb07f522cc60519f4fee585_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
";
        
        $__internal_a120e020da9eb9b8ef4e3498818ee4b7d87af81bc2d9e0d17129470ef5fe6ec1->leave($__internal_a120e020da9eb9b8ef4e3498818ee4b7d87af81bc2d9e0d17129470ef5fe6ec1_prof);

        
        $__internal_5550285b1606262e783eb9a0ba8be4e8f048308dfbb07f522cc60519f4fee585->leave($__internal_5550285b1606262e783eb9a0ba8be4e8f048308dfbb07f522cc60519f4fee585_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/chevron-right.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
", "@Twig/images/chevron-right.svg", "/Users/fabian/proyectos/cursos/symfony/red_social/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/images/chevron-right.svg");
    }
}

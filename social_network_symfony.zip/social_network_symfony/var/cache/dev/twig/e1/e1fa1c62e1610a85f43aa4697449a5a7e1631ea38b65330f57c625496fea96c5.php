<?php

/* user/edit_user.html.twig */
class __TwigTemplate_0ede5b025f63c23d15cb8d96b55cc5abeb14db15cad127301b401707817e5c43 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout/layout.html.twig", "user/edit_user.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c6d1ade96a962613cd8197bc5fc7dfb8bca83e7212951ddf90bcb481157536a3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c6d1ade96a962613cd8197bc5fc7dfb8bca83e7212951ddf90bcb481157536a3->enter($__internal_c6d1ade96a962613cd8197bc5fc7dfb8bca83e7212951ddf90bcb481157536a3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/edit_user.html.twig"));

        $__internal_92e61c5f458027bf11b5b57ae916014c45802ea3861e75237981dcf3e6587f6a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_92e61c5f458027bf11b5b57ae916014c45802ea3861e75237981dcf3e6587f6a->enter($__internal_92e61c5f458027bf11b5b57ae916014c45802ea3861e75237981dcf3e6587f6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/edit_user.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c6d1ade96a962613cd8197bc5fc7dfb8bca83e7212951ddf90bcb481157536a3->leave($__internal_c6d1ade96a962613cd8197bc5fc7dfb8bca83e7212951ddf90bcb481157536a3_prof);

        
        $__internal_92e61c5f458027bf11b5b57ae916014c45802ea3861e75237981dcf3e6587f6a->leave($__internal_92e61c5f458027bf11b5b57ae916014c45802ea3861e75237981dcf3e6587f6a_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_2e67dac4c99ee9cca9fea998097aa08d435cb73359e593a2deabb768e1f61957 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2e67dac4c99ee9cca9fea998097aa08d435cb73359e593a2deabb768e1f61957->enter($__internal_2e67dac4c99ee9cca9fea998097aa08d435cb73359e593a2deabb768e1f61957_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_506c21720ee2faf7185d5cd3522619a5b199a95a3219114ece0fb050a7167911 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_506c21720ee2faf7185d5cd3522619a5b199a95a3219114ece0fb050a7167911->enter($__internal_506c21720ee2faf7185d5cd3522619a5b199a95a3219114ece0fb050a7167911_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "<div class=\"container\">
  <div class=\"col-lg-8 box-form\">
    <h2>Mis Datos</h2>
    <hr>
    ";
        // line 7
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("enctype" => "multipart/form-data"));
        echo "
    ";
        // line 8
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
  </div>
</div>
";
        
        $__internal_506c21720ee2faf7185d5cd3522619a5b199a95a3219114ece0fb050a7167911->leave($__internal_506c21720ee2faf7185d5cd3522619a5b199a95a3219114ece0fb050a7167911_prof);

        
        $__internal_2e67dac4c99ee9cca9fea998097aa08d435cb73359e593a2deabb768e1f61957->leave($__internal_2e67dac4c99ee9cca9fea998097aa08d435cb73359e593a2deabb768e1f61957_prof);

    }

    public function getTemplateName()
    {
        return "user/edit_user.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  59 => 8,  55 => 7,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout/layout.html.twig' %}
{% block content %}
<div class=\"container\">
  <div class=\"col-lg-8 box-form\">
    <h2>Mis Datos</h2>
    <hr>
    {{form_start(form, {'enctype': 'multipart/form-data'})}}
    {{form_end(form)}}
  </div>
</div>
{% endblock %}", "user/edit_user.html.twig", "/Users/fabian/proyectos/cursos/symfony/red_social/app/Resources/views/user/edit_user.html.twig");
    }
}

<?php

/* publication/home.html.twig */
class __TwigTemplate_02394e6592d37614666086754b08e56f363f9e257090551655f818595219563d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout/layout.html.twig", "publication/home.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b632e7ca2b6d3537742487314f37ea7c0f14ac59cc50177f178e83fa75c795a5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b632e7ca2b6d3537742487314f37ea7c0f14ac59cc50177f178e83fa75c795a5->enter($__internal_b632e7ca2b6d3537742487314f37ea7c0f14ac59cc50177f178e83fa75c795a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "publication/home.html.twig"));

        $__internal_7312a55e46ef349a53bfbaa74c26944fd0515941f299ff139964747a51968273 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7312a55e46ef349a53bfbaa74c26944fd0515941f299ff139964747a51968273->enter($__internal_7312a55e46ef349a53bfbaa74c26944fd0515941f299ff139964747a51968273_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "publication/home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b632e7ca2b6d3537742487314f37ea7c0f14ac59cc50177f178e83fa75c795a5->leave($__internal_b632e7ca2b6d3537742487314f37ea7c0f14ac59cc50177f178e83fa75c795a5_prof);

        
        $__internal_7312a55e46ef349a53bfbaa74c26944fd0515941f299ff139964747a51968273->leave($__internal_7312a55e46ef349a53bfbaa74c26944fd0515941f299ff139964747a51968273_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_94e4c7edfefe65232cfb844dd996e25ff304caa4f698562604f1449b66cabc68 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_94e4c7edfefe65232cfb844dd996e25ff304caa4f698562604f1449b66cabc68->enter($__internal_94e4c7edfefe65232cfb844dd996e25ff304caa4f698562604f1449b66cabc68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_2052f71ccf8d804ee812e48c8a9b3b96fd1904b9746345620b67c993c3eaeb7c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2052f71ccf8d804ee812e48c8a9b3b96fd1904b9746345620b67c993c3eaeb7c->enter($__internal_2052f71ccf8d804ee812e48c8a9b3b96fd1904b9746345620b67c993c3eaeb7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "    <h1>Hola</h1>
";
        
        $__internal_2052f71ccf8d804ee812e48c8a9b3b96fd1904b9746345620b67c993c3eaeb7c->leave($__internal_2052f71ccf8d804ee812e48c8a9b3b96fd1904b9746345620b67c993c3eaeb7c_prof);

        
        $__internal_94e4c7edfefe65232cfb844dd996e25ff304caa4f698562604f1449b66cabc68->leave($__internal_94e4c7edfefe65232cfb844dd996e25ff304caa4f698562604f1449b66cabc68_prof);

    }

    public function getTemplateName()
    {
        return "publication/home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout/layout.html.twig' %}
{% block content %}
    <h1>Hola</h1>
{% endblock %}", "publication/home.html.twig", "/Users/fabian/proyectos/cursos/symfony/red_social/app/Resources/views/publication/home.html.twig");
    }
}

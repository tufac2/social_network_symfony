<?php

/* user/users.html.twig */
class __TwigTemplate_f40a7e75558ac8dfd29e05f870c60e27d521258a813e0ca2c9566416890baa77 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout/layout.html.twig", "user/users.html.twig", 1);
        $this->blocks = array(
            'javascripts' => array($this, 'block_javascripts'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2258ae0b22050589b6e3832e5ac9de6ffeaf80b546df0c26412a457822abdf34 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2258ae0b22050589b6e3832e5ac9de6ffeaf80b546df0c26412a457822abdf34->enter($__internal_2258ae0b22050589b6e3832e5ac9de6ffeaf80b546df0c26412a457822abdf34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/users.html.twig"));

        $__internal_f06772f29b4f2b2235dc0e26dec7b8440bce6f13ce5b66cebdecf4e0d8d26c3d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f06772f29b4f2b2235dc0e26dec7b8440bce6f13ce5b66cebdecf4e0d8d26c3d->enter($__internal_f06772f29b4f2b2235dc0e26dec7b8440bce6f13ce5b66cebdecf4e0d8d26c3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/users.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2258ae0b22050589b6e3832e5ac9de6ffeaf80b546df0c26412a457822abdf34->leave($__internal_2258ae0b22050589b6e3832e5ac9de6ffeaf80b546df0c26412a457822abdf34_prof);

        
        $__internal_f06772f29b4f2b2235dc0e26dec7b8440bce6f13ce5b66cebdecf4e0d8d26c3d->leave($__internal_f06772f29b4f2b2235dc0e26dec7b8440bce6f13ce5b66cebdecf4e0d8d26c3d_prof);

    }

    // line 2
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_b84c148c9d1a9e625517e64c7ae72080394619f7ab681204ca8fb8881980fd7d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b84c148c9d1a9e625517e64c7ae72080394619f7ab681204ca8fb8881980fd7d->enter($__internal_b84c148c9d1a9e625517e64c7ae72080394619f7ab681204ca8fb8881980fd7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_f7ca8ce00252551280c7daefff5666ec321f13384a32069afcb71db34c6356cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f7ca8ce00252551280c7daefff5666ec321f13384a32069afcb71db34c6356cf->enter($__internal_f7ca8ce00252551280c7daefff5666ec321f13384a32069afcb71db34c6356cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 3
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/custom/nick-test.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_f7ca8ce00252551280c7daefff5666ec321f13384a32069afcb71db34c6356cf->leave($__internal_f7ca8ce00252551280c7daefff5666ec321f13384a32069afcb71db34c6356cf_prof);

        
        $__internal_b84c148c9d1a9e625517e64c7ae72080394619f7ab681204ca8fb8881980fd7d->leave($__internal_b84c148c9d1a9e625517e64c7ae72080394619f7ab681204ca8fb8881980fd7d_prof);

    }

    // line 6
    public function block_content($context, array $blocks = array())
    {
        $__internal_30cf14d339aa434278be1ece8516d5b17493debbc0f775772f7350f84ba7097d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_30cf14d339aa434278be1ece8516d5b17493debbc0f775772f7350f84ba7097d->enter($__internal_30cf14d339aa434278be1ece8516d5b17493debbc0f775772f7350f84ba7097d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_78ccce6ff3aff814be0a7b77cc7f3869eb5ba2a057499b5896cdb9068ac58cee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_78ccce6ff3aff814be0a7b77cc7f3869eb5ba2a057499b5896cdb9068ac58cee->enter($__internal_78ccce6ff3aff814be0a7b77cc7f3869eb5ba2a057499b5896cdb9068ac58cee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 7
        echo "    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-lg-12 box-form\">
              <h1>Hola People</h1>
              <div class=\"count\">
                <span>
                  Total de Usuarios Registrados
                </span>
                <span class=\"label label-primary\">
                  ";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")), "getTotalItemCount", array(), "method"), "html", null, true);
        echo "
                </span>
              </div>
              <div class=\"box-content box-users\">
                ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination")));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 21
            echo "                  <span>Nombre : ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "name", array()), "html", null, true);
            echo "
                  <span>Email: ";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "email", array()), "html", null, true);
            echo "
                  <br>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "              </div>
            </div>
        </div>
    </div>
";
        
        $__internal_78ccce6ff3aff814be0a7b77cc7f3869eb5ba2a057499b5896cdb9068ac58cee->leave($__internal_78ccce6ff3aff814be0a7b77cc7f3869eb5ba2a057499b5896cdb9068ac58cee_prof);

        
        $__internal_30cf14d339aa434278be1ece8516d5b17493debbc0f775772f7350f84ba7097d->leave($__internal_30cf14d339aa434278be1ece8516d5b17493debbc0f775772f7350f84ba7097d_prof);

    }

    public function getTemplateName()
    {
        return "user/users.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  112 => 25,  103 => 22,  98 => 21,  94 => 20,  87 => 16,  76 => 7,  67 => 6,  55 => 4,  50 => 3,  41 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout/layout.html.twig' %}
{% block javascripts %}
    {{ parent() }}
    <script src=\"{{ asset('assets/js/custom/nick-test.js') }}\"></script>
{% endblock %}
{% block content %}
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-lg-12 box-form\">
              <h1>Hola People</h1>
              <div class=\"count\">
                <span>
                  Total de Usuarios Registrados
                </span>
                <span class=\"label label-primary\">
                  {{ pagination.getTotalItemCount() }}
                </span>
              </div>
              <div class=\"box-content box-users\">
                {% for user in pagination %}
                  <span>Nombre : {{ user.name }}
                  <span>Email: {{ user.email }}
                  <br>
                {% endfor %}
              </div>
            </div>
        </div>
    </div>
{% endblock %}", "user/users.html.twig", "/Users/fabian/proyectos/cursos/symfony/red_social/app/Resources/views/user/users.html.twig");
    }
}

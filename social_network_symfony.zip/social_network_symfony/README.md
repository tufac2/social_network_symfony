# social_network_symfony
Creating a Social Network with Symfony + Jquery + Ajax
